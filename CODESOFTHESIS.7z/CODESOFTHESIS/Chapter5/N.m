% y'(x)=y(x)(ro*x^n)/(alpha+x^n)

% 1
[x,y]=ode45(@varn,[0 1],[1 1 1 1]);
figure
plot(x,y(:,1),'-k',x,y(:,2),'-*k',x,y(:,3),'-.k',x,y(:,4),'-ok')
grid on
xlabel('\fontsize{14}{T_M(t)+T_I(t)}')
ylabel('\fontsize{14}I(t)')
title('\fontsize{14}Immune systems response to the presence of tumor cells for \rho=0.2 and \alpha=0.1')
h=legend('n=0.5','n=1','n=2','n=5');
set(h,'fontsize',14)
%  
 function dydx=varn(x,y)
dydx=zeros(size(y));
dydx(1)=y(1)*(0.2*sqrt(x))/(0.1+sqrt(x));
dydx(2)=y(2)*(0.2*x)/(0.1+x);
dydx(3)=y(3)*(0.2*x^2)/(0.1+x^2);
dydx(4)=y(4)*(0.2*x^5)/(0.1+x^5);
 end
%  
% % 2
% [x,y]=ode45(@varn,[0 1],[1 1 1 1]);
% figure
% plot(x,y(:,1),'-k',x,y(:,2),'-*k',x,y(:,3),'-.k',x,y(:,4),'-ok')
% grid on
% xlabel('\fontsize{16}{T_M(t)+T_I(t)}')
% ylabel('\fontsize{16}I(t)')
% title('\fontsize{16}Immune systems response to the presence of tumor cells for  \rho=0.2 and \alpha=0.3')
% h=legend('n=0.5','n=1','n=2','n=5');
% set(h,'fontsize',16)
%  
%  function dydx=varn(x,y)
% dydx=zeros(size(y));
% dydx(1)=y(1)*(0.2*sqrt(x))/(0.3+sqrt(x));
% dydx(2)=y(2)*(0.2*x)/(0.3+x);
% dydx(3)=y(3)*(0.2*x^2)/(0.3+x^2);
% dydx(4)=y(4)*(0.2*x^5)/(0.3+x^5);
%  end
%  

% sol1=ode45(@varn1,[0 1],[1 1 1 1]);
% sol2=ode45(@varn2,[0 1],[1 1 1 1]);

%box on
% figure
% plot(x,y(:,1),'-k',x,y(:,2),'-*k',x,y(:,3),'-.k',x,y(:,4),'-ok')
% grid on
% h=legend('n=0.5','n=1','n=2','n=5')
% set(h,'fontsize',16)
% figure

%subplot(1,2,1)
%plot(x,y(:,1),'-k',x,y(:,2),'-*k',x,y(:,3),'-.k',x,y(:,4),'-ok')


% plot(sol1.x,sol1.y,'linewidth',2)
% grid on
% xlabel('\fontsize{16}{T_M(t)+T_I(t)}')
% ylabel('\fontsize{16}I(t)')
% title('Immune systems response to the presence of tumor cells for \rho=0.1 and \alpha=0.2')
% h=legend('n=0.5','n=1','n=2','n=5');
% set(h,'fontsize',16)

% subplot(1,2,2)
% plot(sol2.x,sol2.y,'linewidth',2)
% grid on
% %plot(x,y(:,1),'-k',x,y(:,2),'-*k',x,y(:,3),'-.k',x,y(:,4),'-ok')
% h=legend('n=0.5','n=1','n=2','n=5');
% set(h,'fontsize',16)
% xlabel('\fontsize{16}{T_M(t)+T_I(t)}')
% ylabel('\fontsize{16}I(t)')
% title('Immune systems response to the presence of tumor cells for \rho=0.2 and \alpha=0.3')




% function dydx=varn1(x,y)
% dydx=zeros(size(y));
% dydx(1)=y(1)*(0.1*sqrt(x))/(0.2+sqrt(x));
% dydx(2)=y(2)*(0.1*x)/(0.2+x);
% dydx(3)=y(3)*(0.1*x^2)/(0.2+x^2);
% dydx(4)=y(4)*(0.1*x^5)/(0.2+x^5);
% end
% 
% function dydx=varn2(x,y)
% dydx=zeros(size(y));
% dydx(1)=y(1)*(0.2*sqrt(x))/(0.3+sqrt(x));
% dydx(2)=y(2)*(0.2*x)/(0.3+x);
% dydx(3)=y(3)*(0.2*x^2)/(0.3+x^2);
% dydx(4)=y(4)*(0.2*x^5)/(0.32+x^5);
% end
% 

% % y0=0;
% % xspan=[0 1];
% [x,y]=ode45(@difern,[0 1],[0; 0; 0; 0]);
% % xi=linspace(xspan(1), xspan(2),30);
% % yi=spline(x,y,xi);
% % plot(x,y,'o',xi,yi);
% figure
% plot(x,y)
% 
% function dydx=difern(x,y)%RHS
% dydx=zeros(size(y));
% y(1)=A;
% y(2)=B;
% y(3)=C;
% y(4)=D;
% ro=0.1;%parameters should be defined here
% alpha=0.2;
% % dydx(1)=A*(ro*sqrt(x))/(alpha+sqrt(x));
% % dydx(2)=B*(ro*x)/(alpha+x);
% % dydx(3)=C*(ro*x^2)/(alpha+x^2);
% % dydx(4)=D*(ro*x^4)/(alpha+x^4);
% 
% dydx=[A*(ro*sqrt(x))/(alpha+sqrt(x));
%    B*(ro*x)/(alpha+x);
%    C*(ro*x^2)/(alpha+x^2);
%    D*(ro*x^4)/(alpha+x^4)];
% end