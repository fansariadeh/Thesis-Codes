%*****************************************
% in this code I tried to write formulas in general form and define 
% parameters separately.
% up to here everything is fine.
% here I used Initical condition of paper 2

%**********  NoDelay  **************
 
%  y0=[0.171125; 0.5086915; 0.1562305; 0.0795899];
% [t, y]=ode45(@odepn,[0 60],y0);


%********** Delay  *****************
lags=2;
sol1=dde23(@ddepd,lags,@ddehisd,[0,50]);
%********************************

figure
%plot(sol2.x,sol2.y','linewidth',2)
plot(sol1.x,sol1.y(1,:), sol1.x,sol1.y(2,:),...
    sol1.x,sol1.y(3,:),sol1.x,sol1.y(4,:),'linewidth',2.5);

%plot(sol1.x,sol1.y(2,:),sol1.x,sol1.y(3,:),sol1.x,sol1.y(2,:)+sol1.y(3,:),'linewidth',2.5);

grid on
h=legend('N(t)','T_I(t)','T_M(t)','I(t)');
set(h,'fontsize',24)
xlabel('\fontsize{25}Time (Day)')
ylabel('\fontsize{25} Number of cells \times 10^{11}')
title('Population of cells over time, \tau=2','fontsize',32)
h=legend('N(t)','T_I(t)','T_M(t)','I(t)');
set(h,'fontsize',24)
ax = gca;
ax.LineWidth = 2.5;
set(gca,'FontSize',20)

function S=ddehisd(t)
S=[0.171125;0.209571; 0.069857; 0.157805];
end
% ********** system of equations ************
function dydt=ddepd(t,y,Z)
% % parameters
r=1.1;
b1=1;
b2=0.81;
c1=0.948;c2=0.9;c3=1;c4=0.015;
c5=1;c6=0.065;c7=0.6;c8=0.55;
alpha=0.3;alphaI=0.8;alphaM=0.98;
betaI=0.11;betaM=0.4;
d=0.2;
rho=0.2;
s=0.33;

ylag1=Z(:,1);
dydt=[y(1)*(1-y(1)/b1)-c1*y(2)*y(1)-c2*y(3)*y(1);
    r*y(2)*(1-y(2)/b2)+2*alphaI*y(3)-alphaM*ylag1(2)-betaI*y(2)-c3*y(2)*y(4)-c4*y(2)*y(1);
    alphaM*ylag1(2)-alphaI*y(3)-betaM*y(3)-c5*y(3)*y(4)-c6*y(1)*y(3);
    s+rho*(y(4)*(y(2)+y(3)))/(alpha+y(2)+y(3))-c7*y(2)*y(4)-c8*y(3)*y(4)-d*y(4)];
end