% Magnitude is 5

%% MTD decaying injection

t = 0 : 1/100 : 90;
y=5*heaviside(t)-5*heaviside(t-0.25)+5*exp(-(t-0.25)./8).*heaviside(t-0.25)+...
    5*heaviside(t-21)-5*heaviside(t-21.25)+5*exp(-(t-21.25)./8).*heaviside(t-21.25)+...
    5*heaviside(t-42)-5*heaviside(t-42.25)+5*exp(-(t-42.25)./8).*heaviside(t-42.25)+...
    5*heaviside(t-63)-5*heaviside(t-63.25)+5*exp(-(t-63.25)./8).*heaviside(t-63.25)+...
    5*heaviside(t-84)-5*heaviside(t-84.25)+5*exp(-(t-84.25)./8).*heaviside(t-84.25);
    
plot(t,y,'LineWidth',6)
grid on
xlabel('Time (Day)','fontsize',50)
ylabel('Dosage of injected druge','fontsize',50)
%title('C(t): Chemotherapy injection every 3 weeks (MTD)','fontsize',32)
ax = gca;
set(gca,'FontSize',50)
ax.LineWidth = 6;
axis ([0 90 0 5.5])

% It finds minimum
[pks,locs]=findpeaks(-y,t);
ymin=max(pks);
% absolute value of this will be the minimum value of function

%findng Max
% [pksm,locsm]=findpeaks(y,t);
% ymax=max(pksm);
% 
% indexmax = find(max(pksm) == t);
% tmax = t(indexmax);

% t1=15;
% y1=5.4;
% txt1='5.3732';
% text(t1,y1,txt1,'Color','red','FontSize',28)
% 
% 
% t2=35;
% y2=5.4;
% txt2='5.40026';
% text(t2,y2,txt2,'Color','red','FontSize',28)
% 
% t3=56;
% y3=5.4;
% txt3='5.40222';
% text(t3,y3,txt3,'Color','red','FontSize',28)
% 
% 
% t4=78;
% y4=5.4;
% txt4='5.40236';
% text(t4,y4,txt4,'Color','red','FontSize',28)
% 
% 
% 
% 
% t5=18;
% y5=0.25;
% txt5='0.37416';
% text(t5,y5,txt5,'Color','red','FontSize',28)
% 
% 
% t6=40;
% y6=0.25;
% txt6='0.40126';
% text(t6,y6,txt6,'Color','red','FontSize',28)
% 
% t7=60;
% y7=0.25;
% txt7='0.40323';
% text(t7,y7,txt7,'Color','red','FontSize',28)
% 
% t8=80;
% y8=0.25;
% txt8='0.40337';
% text(t8,y8,txt8,'Color','red','FontSize',28)
% 
% %text(locsm+.8,pksm,num2str((pksm(1:4))))
% % plot(t,y,'LineWidth',2.5)
% % grid on
% % xlabel('Time (Day)','fontsize',28)
% % ylabel('Dosage of injected druge','fontsize',24)
% % title('C(t): Chemotherapy injection every three weeks','fontsize',18)
% % ax = gca;
% % ax.LineWidth = 1.5;
% % axis ([0 100 -0.5 1.5])
%  xx=41:0.4:45;
%  yy=4.5:0.1:5.5;


% 
% % create a new pair of axes inside current figure
% axes('position',[.2 .2 0.5 0.3]);
% box on
% u_index= 41<t & t<50;
% plot(t(u_index),y(u_index));
% axis tight
