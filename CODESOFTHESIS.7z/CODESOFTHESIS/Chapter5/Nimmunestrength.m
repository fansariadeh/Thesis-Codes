%*****************************************
% in this code I tried to write formulas in general form and define 
% parameters separately.
% up to here everything is fine.
% here I used Initical condition of paper 2


% %**********  NoDelay  **************
%  
%  y0=[0.171125; 0.5086915; 0.1562305; 0.0795899];
% [t, y]=ode45(@odepn,[0 60],y0);


%********** Delay  *****************
lags=2;
sol2=dde23(@ddepd,lags,@ddehisd,[0,30],[],0.05);
sol3=dde23(@ddepd,lags,@ddehisd,[0,30],[],0.1);
sol4=dde23(@ddepd,lags,@ddehisd,[0,30],[],0.2);
sol5=dde23(@ddepd,lags,@ddehisd,[0,30],[],0.3);
sol6=dde23(@ddepd,lags,@ddehisd,[0,30],[],0.5);
%********************************


figure
plot(sol2.x,sol2.y(2,:)+sol2.y(3,:),sol3.x,sol3.y(2,:)+sol3.y(3,:),sol4.x,sol4.y(2,:)+sol4.y(3,:)...
    ,sol5.x,sol5.y(2,:)+sol5.y(3,:),sol6.x,sol6.y(2,:)+sol6.y(3,:),'linewidth',6)
grid on
h=legend('s=0.05', 's=0.1','s=0.2','s=0.3', 's=0.5');
set(h,'fontsize',50)
xlabel('\fontsize{50} Time (Day)')
ylabel(' \fontsize{50} Number of tumour cells  \times 10^{11}')
%title('T_I(t)+T_M(t) for different immune system strength','fontsize',60)
ax = gca;
ax.LineWidth = 6;
set(gca,'FontSize',50)

% x1=20;y1=1.45;txt1=' \bf s=0.05';
% text(x1,y1,txt1,'HorizontalAlignment','right');
% 
% x2=18;y2=1.2;txt2=' \bf s=0.1';
% text(x2,y2,txt2,'HorizontalAlignment','right');
% 
% x3=15;y3=0.5;txt3=' \bf s=0.2';
% text(x3,y3,txt3,'HorizontalAlignment','right');
% 
% x4=8;y4=0.3;txt4=' \bf s=0.3';
% text(x4,y4,txt4,'HorizontalAlignment','right');
% 
% x5=4;y5=0.1;txt5=' \bf s=0.5';
% text(x5,y5,txt5,'HorizontalAlignment','right');


%************ history function *********
%**** history should be function of time or position *****
function S=ddehisd(t,s)
S=[0.171125;0.209571 ; 0.069857; 0.157805];
end
% ********** system of equations ************
function dydt=ddepd(t,y,Z,s)
% % parameters
r=1.1;
b1=1;
b2=0.81;
c1=0.948;c2=0.9;c3=1;c4=0.015;
c5=1;c6=0.065;c7=0.6;c8=0.55;
alpha=0.3;alphaI=0.8;alphaM=0.98;
betaI=0.11;betaM=0.4;
d=0.2;
rho=0.2;
%s=0.1;
ylag1=Z(:,1);

dydt=[y(1)*(1-y(1)/b1)-c1*y(2)*y(1)-c2*y(3)*y(1);
    r*y(2)*(1-y(2)/b2)+2*alphaI*y(3)-alphaM*ylag1(2)-betaI*y(2)-c3*y(2)*y(4)-c4*y(2)*y(1);
    alphaM*ylag1(2)-alphaI*y(3)-betaM*y(3)-c5*y(3)*y(4)-c6*y(1)*y(3);
    s+rho*(y(4)*((y(2)+y(3))^(1)))/(alpha+(y(2)+y(3))^(1))-c7*y(2)*y(4)-c8*y(3)*y(4)-d*y(4)];
end

