

x1 = linspace(-90,0);
x = linspace(-88,0);
y1=(0.07/90)*x1+0.07;
y = (0.21/88)*x+0.21;


%subplot(2,1,1)
% p=plot(x1,y1);
% set(p,'LineWidth',6)
% grid on
% grid minor
% axis([-95 10 -0.01 0.1])
% ax = gca;
% ax.LineWidth = 1;
% set(gca,'FontSize',50)
% ax.XAxisLocation = 'origin';
% ax.YAxisLocation = 'origin';
% xlabel('Time (Day)','fontsize',50)
% ylabel('Number of T_I cells ( \times 10^{11})','fontsize',50)
%title('History function of T_I(t) cells growth','fontsize',14)
% title('History function of T_I(t) cells','fontsize',20)
% subplot(2,1,2)
pp=plot(x,y);
set(pp,'LineWidth',6)
grid on
grid minor
axis([-95 10 -0.02 0.25])
ax = gca;
ax.LineWidth = 1;
set(gca,'FontSize',20)

 xticks([-90  -80 -70 -60 -50 -40 -30 -20 -10 0 ])
 xticklabels({'-90','-80','-70','-60','-50','-40','-30','-20','-10','0'})

 yticks([0 0.1  0.21 ])
 yticklabels({'0','0.1','0.21'})
ax = gca;
ax = gca;
ax.LineWidth = 1;
set(gca,'FontSize',45)
ax.XAxisLocation = 'origin';
ax.YAxisLocation = 'origin';
xlabel('Time (Day)','fontsize',50)
ylabel('Number of T_M cells ( \times 10^{11})','fontsize',50)
title('History function of T_M(t) cells','fontsize',20)
