%% decaying injection

t = 0 : 1/100 : 90;
y=heaviside(t)-heaviside(t-0.25)+exp(-(t-0.25)./8).*heaviside(t-0.25)+...
    heaviside(t-7)-heaviside(t-7.25)+exp(-(t-7.25)./8).*heaviside(t-7.25)+...
    heaviside(t-14)-heaviside(t-14.25)+exp(-(t-14.25)./8).*heaviside(t-14.25)+...
    heaviside(t-21)-heaviside(t-21.25)+exp(-(t-21.25)./8).*heaviside(t-21.25)+...
    heaviside(t-28)-heaviside(t-28.25)+exp(-(t-28.25)./8).*heaviside(t-28.25)+...
    heaviside(t-35)-heaviside(t-35.25)+exp(-(t-35.25)./8).*heaviside(t-35.25)+...
    heaviside(t-42)-heaviside(t-42.25)+exp(-(t-42.25)./8).*heaviside(t-42.25)+...
    heaviside(t-49)-heaviside(t-49.25)+exp(-(t-49.25)./8).*heaviside(t-49.25)+...
    heaviside(t-56)-heaviside(t-56.25)+exp(-(t-56.25)./8).*heaviside(t-56.25)+...
    heaviside(t-63)-heaviside(t-63.25)+exp(-(t-63.25)./8).*heaviside(t-63.25)+...
    heaviside(t-70)-heaviside(t-70.25)+exp(-(t-70.25)./8).*heaviside(t-70.25)+...
    heaviside(t-77)-heaviside(t-77.25)+exp(-(t-77.25)./8).*heaviside(t-77.25)+...
    heaviside(t-84)-heaviside(t-84.25)+exp(-(t-84.25)./8).*heaviside(t-84.25);
    

% It finds minimum
[pks,locs]=findpeaks(-y,t);
ymin=max(pks);
% absolute value of this will be the minimum value of function

%findng Max
[pksm,locsm]=findpeaks(y,t);
ymax=max(pksm);

indexmax = find(max(pksm) == t);
tmax = t(indexmax);

plot(t,y,'LineWidth',6)
grid on
xlabel('Time (Day)','fontsize',50)
ylabel('Dosage of drug','fontsize',50)
%title('C(t): Chemotherapy injection every week (Metronomic)','fontsize',32)
ax = gca;
set(gca,'FontSize',60)
ax.LineWidth = 6;
axis ([0 90 0 1.8])


% t1=3;
% y1=1.4;
% txt1='1.4296';
% text(t1,y1,txt1,'Color','red','FontSize',22)
% 
% 
% t2=10;
% y2=1.6;
% txt2='1.6086';
% text(t2,y2,txt2,'Color','red','FontSize',22)
% 
% t3=17;
% y3=1.7;
% txt3='1.683';
% text(t3,y3,txt3,'Color','red','FontSize',22)
% 
% 
% t4=24;
% y4=1.75;
% txt4='1.714';
% text(t4,y4,txt4,'Color','red','FontSize',22)
% 
% 
% t5=31;
% y5=1.75;
% txt5='1.727';
% text(t5,y5,txt5,'Color','red','FontSize',22)
% 
% 
% t6=38;
% y6=1.75;
% txt6='1.733';
% text(t6,y6,txt6,'Color','red','FontSize',22)
% 
% t7=45;
% y7=1.75;
% txt7='1.735';
% text(t7,y7,txt7,'Color','red','FontSize',22)
% 
% 
% t8=52;
% y8=1.75;
% txt8='1.736';
% text(t8,y8,txt8,'Color','red','FontSize',22)
% 
% 
% t9=59;
% y9=1.75;
% txt9='1.73635';
% text(t9,y9,txt9,'Color','red','FontSize',22)
% 
% 
% t10=66;
% y10=1.75;
% txt10='1.7365';
% text(t10,y10,txt10,'Color','red','FontSize',22)
% 
% 
% t11=73;
% y11=1.75;
% txt11='1.73658';
% text(t11,y11,txt11,'Color','red','FontSize',22)
% 
% 
% t12=80;
% y12=1.75;
% txt12='1.7366';
% text(t12,y12,txt12,'Color','red','FontSize',22)




% t13=6;
% y13=0.4;
% txt13='0.431';
% text(t13,y13,txt13,'Color','red','FontSize',22)
% 
% t14=13;
% y14=0.6;
% txt14='0.610';
% text(t14,y14,txt14,'Color','red','FontSize',22)
% 
% t15=20;
% y15=0.7;
% txt15='0.685';
% text(t15,y15,txt15,'Color','red','FontSize',22)
% 
% t16=27;
% y16=0.7;
% txt16='0.7162';
% text(t16,y16,txt16,'Color','red','FontSize',22)
% 
% t17=33;
% y17=0.7;
% txt17='0.7292';
% text(t17,y17,txt17,'Color','red','FontSize',22)
% 
% t18=40;
% y18=0.7;
% txt18='0.7346';
% text(t18,y18,txt18,'Color','red','FontSize',22)
% 
% t19=47;
% y19=0.7;
% txt19='0.73686';
% text(t19,y19,txt19,'Color','red','FontSize',22)
% 
% t20=54;
% y20=0.7;
% txt20='0.7378';
% text(t20,y20,txt20,'Color','red','FontSize',22)
% 
% t21=61;
% y21=0.7;
% txt21='0.7382';
% text(t21,y21,txt21,'Color','red','FontSize',22)
% 
% t22=68;
% y22=0.7;
% txt22='0.7383';
% text(t22,y22,txt22,'Color','red','FontSize',22)
% 
% t23=75;
% y23=0.7;
% txt23='0.7384';
% text(t23,y23,txt23,'Color','red','FontSize',22)
% 
% t24=82;
% y24=0.7;
% txt24='0.7385';
% text(t24,y24,txt24,'Color','red','FontSize',22)
